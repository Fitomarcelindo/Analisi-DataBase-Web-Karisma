from django.contrib.admin import site
from .models import Files

# Register your models here.
site.register(Files)
