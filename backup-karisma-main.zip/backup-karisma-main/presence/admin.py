from django.contrib.admin import site
from .models import *

# Register your models here.
site.register(ClassName)
site.register(UserData)
site.register(GenerateQRCode)
site.register(Recap)
site.register(BoardingHouse)
